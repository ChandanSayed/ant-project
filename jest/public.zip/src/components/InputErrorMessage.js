import React from 'react'

const InputErrorMessage = () => {
  return (
    <>
      <br /> <small style={{ color: "red" }}>Fields cannot be empty!</small>
    </>
  )
}

export default InputErrorMessage